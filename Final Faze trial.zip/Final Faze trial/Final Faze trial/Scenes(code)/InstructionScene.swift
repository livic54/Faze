//
//  InstructionScene.swift
//  Final Faze trial
//
//  Created by 李航 on 25/3/2022.
//

import Foundation
import SpriteKit


class InstructionScene: SKScene{
    
    override func didMove(to view: SKView) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
                let location = touch.location(in: self)
                let nodesarray = nodes(at: location)
                 
                for node in nodesarray {
                    if node.name == "homePage" {
                        let startScene = StartScene(fileNamed: "StartScene")
                        let transition = SKTransition.push(with: .down, duration: 0.5)
                        startScene?.scaleMode = .aspectFill
                        scene?.view?.presentScene(startScene!, transition: transition)
                     }
                }
            }
    }
}
