//
//  GameScene.swift
//  Final Faze trial
//
//  Created by 李航 on 24/3/2022.
//

import Foundation
import SpriteKit

class GameScene: SKScene, SKPhysicsContactDelegate{
    
    var player: SKSpriteNode!
    var isGameOver = false
    var scoreLabel: SKLabelNode!

    var score = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }
    
    override func didMove(to view: SKView) {
        
        scoreLabel = SKLabelNode(fontNamed: "Chalkduster")
        scoreLabel.text = "Score: 0"
        scoreLabel.horizontalAlignmentMode = .left
        scoreLabel.position = CGPoint(x: 90, y: 30)
        addChild(scoreLabel)
        
        loadFile()
        createPlayer()
    
        physicsWorld.contactDelegate = self
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
                let location = touch.location(in: self)
                let nodesarray = nodes(at: location)
                   
                for node in nodesarray {
                    if node.name == "Menu" {
                    let startScene = StartScene(fileNamed: "StartScene")
                        let transition = SKTransition.push(with: .up, duration: 0.5)
                    startScene?.scaleMode = .aspectFill
                    scene?.view?.presentScene(startScene!, transition: transition)
                    }
                }
            }
    }
    
    func loadFile(){
        guard let mapURL = Bundle.main.url(forResource: "level1", withExtension: "txt") else {
            fatalError("There is no file named level1.txt.")
        }
        
        guard let mapString = try? String(contentsOf: mapURL) else{
            fatalError("Can't load the file level1.txt")
        }
        
        let lines = mapString.components(separatedBy: "\n")
        
        for(row, line) in lines.reversed().enumerated(){
            for(column, letter) in line.enumerated(){
                let position = CGPoint(x: (64 * column) + 32, y: (64 * row) + 32)
                
                if letter == "x"{
                    let node = SKSpriteNode(imageNamed: "block")
                    node.position = position
                
                    node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
                    node.physicsBody?.categoryBitMask = CollisionTypes.wall.rawValue
                    node.physicsBody?.isDynamic = false
                    
                    addChild(node)
                }
                else if letter == "v"{
                    let node = SKSpriteNode(imageNamed: "vortex")
                    node.name = "vortex"
                    node.position = position
                    node.run(SKAction.repeatForever(SKAction.rotate(byAngle: .pi, duration: 1)))
                    node.physicsBody = SKPhysicsBody(circleOfRadius: node.size.width/2)
                    node.physicsBody?.isDynamic = false
                    
                    node.physicsBody?.categoryBitMask = CollisionTypes.vortex.rawValue
                    node.physicsBody?.contactTestBitMask = CollisionTypes.player.rawValue
                    node.physicsBody?.collisionBitMask = 0
                    
                    addChild(node)
                }
                else if letter == "s"{
                    let node = SKSpriteNode(imageNamed: "star")
                    node.name = "star"
                    node.position = position
                    node.physicsBody = SKPhysicsBody(circleOfRadius: node.size.width/2)
                    node.physicsBody?.isDynamic = false;
                    
                    node.physicsBody?.categoryBitMask = CollisionTypes.star.rawValue
                    node.physicsBody?.contactTestBitMask = CollisionTypes.player.rawValue
                    node.physicsBody?.collisionBitMask = 0
                    
                    addChild(node)
                }
                else if letter == "f"{
                    let node = SKSpriteNode(imageNamed: "finish")
                    node.name = "finish"
                    node.position = position
                    node.physicsBody = SKPhysicsBody(circleOfRadius: node.size.width/2)
                    node.physicsBody?.isDynamic = false;
                    
                    node.physicsBody?.categoryBitMask = CollisionTypes.finish.rawValue
                    node.physicsBody?.contactTestBitMask = CollisionTypes.player.rawValue
                    node.physicsBody?.collisionBitMask = 0
                    
                    addChild(node)
                }
                else if letter == " "{
                }
                else{
                    fatalError("No such letter here(\(letter)).")
                }
            }
        }
    }
    
    func createPlayer() {
        player = SKSpriteNode(imageNamed: "player")
        player.position = CGPoint(x: 160, y: 1178)
        player.zPosition = 1
        player.physicsBody = SKPhysicsBody(circleOfRadius: player.size.width / 2)
        player.physicsBody?.allowsRotation = false
        player.physicsBody?.affectedByGravity = false
        player.physicsBody?.categoryBitMask = CollisionTypes.player.rawValue
        player.physicsBody?.contactTestBitMask = CollisionTypes.star.rawValue | CollisionTypes.vortex.rawValue | CollisionTypes.finish.rawValue
        player.physicsBody?.collisionBitMask = CollisionTypes.wall.rawValue
        addChild(player)
    }
    
    
    func updatePlayer(movement: MoveDirection){
        // isGameOver is a boolean variable indicate whether the game should end or not
        if !isGameOver{
            move(movement: movement)
        }
    }
    
    func move(movement: MoveDirection){
        var x_delta: CGFloat = 0
        var y_delta: CGFloat = 0
        
        switch movement {
        case .moveLeft:
            x_delta = 40
            y_delta = 0
        case .moveRight:
            x_delta = -40
            y_delta = 0
        case .moveUp:
            x_delta = 0
            y_delta = 40
        case .moveDown:
            x_delta = 0
            y_delta = -40
        }
        let action = SKAction.moveBy(x: x_delta, y: y_delta, duration: 1)
        let sequence = SKAction.sequence([action])
        
        player.run(sequence)
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.node == player {
            playerCollided(with: contact.bodyB.node!)
        } else if contact.bodyB.node == player {
            playerCollided(with: contact.bodyA.node!)
        }
    }
    
    
    
    func playerCollided(with node: SKNode) {
        if node.name == "vortex" {
            player.physicsBody?.isDynamic = false
            score -= 1
            let move = SKAction.move(to: node.position, duration: 0.25)
            let scale = SKAction.scale(to: 0.0001, duration: 0.25)
            let remove = SKAction.removeFromParent()
            let sequence = SKAction.sequence([move, scale, remove])

            player.run(sequence) { [unowned self] in
                self.createPlayer()
                self.isGameOver = false
            }
            
        } else if node.name == "star" {
            node.removeFromParent()
            score += 1
        } else if node.name == "finish" {
            // next level?
            node.removeFromParent()
            isGameOver = true
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
       
    }
    
}
