//
//  StartScene.swift
//  Final Faze trial
//
//  Created by 李航 on 24/3/2022.
//

import SpriteKit

class StartScene: SKScene{
    
    override func didMove(to view: SKView) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
                let location = touch.location(in: self)
                let nodesarray = nodes(at: location)
                   
                for node in nodesarray {
                    if node.name == "Play" {
                    let gameScene = GameScene(fileNamed: "GameScene")
                        let transition = SKTransition.push(with: .up, duration: 0.5)
                    gameScene?.scaleMode = .aspectFill
                    scene?.view?.presentScene(gameScene!, transition: transition)
                    }
                    if node.name == "Instruction" {
                        let insScene = InstructionScene(fileNamed: "InstructionScene")
                        let transition = SKTransition.push(with: .up, duration: 0.5)
                        insScene?.scaleMode = .aspectFill
                        scene?.view?.presentScene(insScene!, transition: transition)
                    }
                }
            }
    }
}
