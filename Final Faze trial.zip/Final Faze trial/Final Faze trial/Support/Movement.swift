//
//  Movement.swift
//  Final Faze trial
//
//  Created by 李航 on 24/3/2022.
//

enum MoveDirection {
    case moveLeft
    case moveRight
    case moveUp
    case moveDown
}
