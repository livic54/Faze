//
//  Scenes.swift
//  Final Faze trial
//
//  Created by 李航 on 24/3/2022.
//

enum Scenes: String{
    case start = "StartScene"
    case game = "GameScene"
    case instruction = "InstructionScene"
}

extension Scenes{
    func getName() -> String{
        return self.rawValue
    }
}
