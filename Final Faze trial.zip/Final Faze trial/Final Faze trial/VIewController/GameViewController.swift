//
//  GameViewController.swift
//  Final Faze trial
//
//  Created by 李航 on 24/3/2022.
//

import UIKit
import SpriteKit
import GameplayKit
import ARKit


class GameViewController: UIViewController, ARSessionDelegate {
    
    var gameScene:GameScene!
    var session:ARSession!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let sceneName = Scenes.game.getName()
        // Load 'GameScene.sks' as a GKScene. This provides gameplay related content
        // including entities and graphs.
        if let scene = SKScene(fileNamed: sceneName) as? GameScene {
            
            gameScene = scene
            // Set the scale mode to scale to fit the window
            gameScene.scaleMode = .aspectFill
                
            // Present the scene
            if let view = self.view as! SKView? {
                view.presentScene(gameScene)
                view.ignoresSiblingOrder = true
            }
            session = ARSession()
            session.delegate = self
        }
    }

    override var shouldAutorotate: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        guard ARFaceTrackingConfiguration.isSupported else {print("iPhone X required"); return}
        
        let configuration = ARFaceTrackingConfiguration()
        
        session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
        
    }
    
    // MARK: ARSession delegate
    func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
        if let faceAnchor = anchors.first as? ARFaceAnchor {
            update(withFaceAnchor: faceAnchor)
        }
    }
    
    
    func update(withFaceAnchor faceAnchor: ARFaceAnchor) {
        
        let bledShapes:[ARFaceAnchor.BlendShapeLocation:Any] = faceAnchor.blendShapes
        
        guard let browUp = bledShapes[.browInnerUp] as? Float else {return}
        guard let mouthLeft = bledShapes[.mouthSmileLeft] as? Float else {return}
        guard let mouthRight = bledShapes[.mouthSmileRight] as? Float else {return}
        guard let tongueOut = bledShapes[.tongueOut] as? Float else {return}

        // move up
        if browUp > 0.7 {
            gameScene.updatePlayer(movement: .moveUp)
        }
        
        // move down
        if tongueOut > 0.45 {
            gameScene.updatePlayer(movement: .moveDown)
        }
        
        //move right
        if mouthRight > 0.4 {
            gameScene.updatePlayer(movement: .moveRight)
        }
        
        //move left
        if mouthLeft > 0.4 {
            gameScene.updatePlayer(movement: .moveLeft)
        }
        
    }
    
}
